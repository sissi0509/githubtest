'''
    Birthday gift for Jiayin
    family_game.py
    29/09/2024
    Xi Zhao
'''

import random, turtle, time

WIDTH = 1200
HEIGHT = 1000
Y = 0
UP_Y = 200
DOWN_Y = -200
LEFT_X = -350
RIGHT_X = 350
MIDDLE_X = 0



def get_player(team):
    """ 
    Function: get_player
        get name for the player
    Parameter: name of the team
    Return: Different names of player (string)
        input number from 1 to 8 assciated with different name
        1 to 4 belong to GIRL team
        5 to 8 belong to BOY team
    """
    if team.upper() == 'BOY':
        number = random.randint(5, 8)
    else:
        number = random.randint(1, 4)
    
    if number == 1:
        return 'Mommy'

    elif number == 2:
        return 'Grandma'

    elif number == 3:
        return 'Granny'

    elif number == 4:
        return 'Sister'

    elif number == 5:
        return 'Daddy'

    elif number == 6:
        return 'Granddad'

    elif number == 7:
        return 'Grandpa'

    elif number == 8:
        return 'Brother'


def roll_dice():
    """
    Function: roll_dice
        get the result of a dice roll
    Returns a random int in the range 2 to 12 (inclusive)
    """

    return random.randint(2, 12)


def is_power_up_active(number):
    """
    Function: is_power_up_active
        check whether get power_tp
    Parameters: number
        a int from the dice roll, within range of 2 to 12
    Return: Ture or False
        True: when number is 7 or 11
        False: other cases
    """

    if number == 7 or number == 11:
        return True

    return False


def check_battle(computer, player):
    '''
    Function: check_battle
        check the result of the  1-to-1 matchup, who has a greater power
    Parameters:
        computer: power values for computer, int
        player: power values for player, int
    Return:
        'COMPUTER': computer wins
        'PLAYER': player wins
        'DRAW!': a tie
    '''

    if computer > player:
        return 'COMPUTER'
    elif computer < player:
        return 'PLAYER'
    else:
        return 'DRAW!'


def team_of_computer(player_team):
    '''
    Function: team_of_computer
        with known player team to find the team of computer
    Parameters:
        player_team: team of player, string
    Return:
        GIRL: if player team is BOY
        BOY: otherwise
    '''
    
    if player_team == 'BOY':
        return 'GIRL'

    return 'BOY'
    

def will_roll():
    '''
    Function:will_roll
        let player to choose roll or not and print the results
    Return:
        True: will roll
        False: not roll
    '''

    # ask the player to make a choice
    print("Highest dice roll wins. If you don't roll, we'll end the match.")
    choice = input('Roll the dice for your character (y/n)? ')
    
    if choice.lower() == 'y':
        return True

    return False

    
def get_power(screen, pokemon_name, team_name):
    '''
    Function: get_power
        get the final power of a pokemon
        show image of who has power-up
        show image of who win
    Parameters:
        screen: where to put image
        pokemon_name: name of pokemon
        team_name: name of the team this pokemon belong
    Return: return the power of the player after two roll
    '''

    # roll once and print the result
    roll_1 = roll_dice()
    print(f"{team_name} team {pokemon_name} rolls {roll_1}")

    # roll the 2nd time and check whether power-up
    roll_2 = roll_dice()

    # if powerup show image of the player
    if is_power_up_active(roll_2):
        print(f"*** {pokemon_name} gets POWER-UP!")
        add_image(screen, MIDDLE_X, DOWN_Y, pokemon_name + '.gif')
        add_image(screen, MIDDLE_X, UP_Y, 'plus_one.gif' )
        time.sleep(1)
        screen.clear()
        print(f"{team_name} team {pokemon_name} has final power {roll_1 + 1}")
        return roll_1 + 1

    print(f"No power-up, {team_name} team {pokemon_name} has final power {roll_1}")
    return roll_1


def team_won_once(
    screen,
    computer_pokemon,
    player_pokemon,
    computer_team,
    player_team
):
    '''
    Function: print_check_result
        check results for one round of two teams
        print the results of two team
    Paramenter:
        screen: which screen
        computer_pokemon: name of computer_pokemon
        player_pokemon: name of computer_pokemon
        computer_team: name of team of computer
        player_team: name of team of player
    return:
        'COMPUTER': if computer team won this round
        'PLAYER': if player won this round
        'DRAW!': a tie
    '''

    pairs = [
        ('Daddy', 'Mommy'),
        ("Grandpa", "Grandma"),
        ("Granddad", "Granny"),
        ("Mommy", 'Daddy'),
        ('Grandma', 'Grandpa'),
        ('Granny', 'Granddad')
    ]
    
    # find power of two pokemon
    computer_power = get_power(screen, computer_pokemon, computer_team)
    player_power = get_power(screen, player_pokemon, player_team)

    # check who win and print it 
    result = check_battle(computer_power, player_power)

    if result == 'COMPUTER':
        add_image(screen, LEFT_X, Y, computer_pokemon + '.gif')
        add_image(screen, MIDDLE_X, Y, 'win.gif')
        time.sleep(1)
        screen.clearscreen()
    elif result == 'PLAYER':
        add_image(screen, RIGHT_X, Y, player_pokemon + '.gif')
        add_image(screen, MIDDLE_X, Y, 'win.gif')
        time.sleep(1)
        screen.clearscreen()
    else:
        if (computer_pokemon, player_pokemon) in pairs:
            add_image(screen, LEFT_X, Y, computer_pokemon + '.gif')
            add_image(screen, RIGHT_X, Y, player_pokemon + '.gif')
            add_image(screen, MIDDLE_X, Y, 'love.gif')
            time.sleep(1)
            screen.clearscreen()
        else:
            add_image(screen, LEFT_X, Y, computer_pokemon + '.gif')
            add_image(screen, RIGHT_X, Y, player_pokemon + '.gif')
            add_image(screen, MIDDLE_X, Y, 'handshake.gif')
            time.sleep(1)
            screen.clearscreen()  
    
    return result


def final_result(
    screen,
    computer_team,
    computer_score,
    player_team,
    player_score
):
    '''
    Function: final_result
        show the final result of the tournament with image
    Paramenter:
        screen: where to show the image
        computer_team :team of computer, string
        computer_score: score of computer, int
        player_team: team of player, string
        player_score: score of player, int
    
    '''

    add_image(screen, MIDDLE_X, Y, 'WINNER.gif')
    time.sleep(1)
    
    # print final score for both teams
    print(f"My team {computer_team}: {computer_score}    "
          f"Your team {player_team}: {player_score}")

    # check the winner and print it and show image of winner
    result = check_battle(computer_score, player_score)

    if result == 'COMPUTER':
        print(f"My team {computer_team} wins the tournament!")
        add_image(screen, MIDDLE_X, Y, computer_team + '.gif')
    elif result == 'PLAYER':
        print(f"Your team {player_team} wins the tournament!")
        add_image(screen, MIDDLE_X, Y, player_team + '.gif')
    else:
        print("We are tied! Great Game!")
        add_image(screen, MIDDLE_X, Y, 'family.gif')

    time.sleep(1)
    screen.clear()
    
    
        

    
def play_or_not():
    '''
    Function: play_or_not
        give player choice to choose whether to play or not
    Return:
        Ture: keep play
        False: not play
    '''

    choice = input("Play again (y/n) ?")

    if choice.lower() == 'y':
        return True

    return False
        

def setup():
    '''
    setup the environment to play the game
    '''

    turtle.hideturtle()
    screen = turtle.Screen()
    screen.setup(WIDTH, HEIGHT)
    # turtle.bgpic(picture)

    return screen


def add_image(screen, x, y, image):
    '''
    add the "image" at (x, y) on the "screen"
    '''

    # creat a turtle with image shape
    pen = turtle.Turtle()
    screen.addshape(image)
    pen.shape(image)

    # position the turtle on the screen
    pen.penup()
    pen.goto(x, y)
    pen.pendown()

def print_rules():
    rules = """
🎉 Want to have some fun? Need to settle a score? Welcome to Family Showdown! 
1. Choose Your Team: Pick your team, and I’ll represent the other team!
2. Roll the Dice: Automatically roll two dice to get your power.
3. Power Up: Roll again to see if you score a power-up!

Let the Family Showdown begin! 🥳
"""
    print(rules)


def display_surprise():
    '''show surprise message from xi'''
    
    # Set up the screen
    screen = turtle.Screen()
    screen.title("Surprise for Jiayin!")
    screen.bgcolor("lightpink")

    # Create a turtle
    pen = turtle.Turtle()
    pen.hideturtle()  # Hide the turtle cursor

    add_image(screen, -350, -200, 'friend_left.gif')
    add_image(screen, 350, -200, 'friend_right.gif')
    add_image(screen, -20, -200, 'Jiayin.gif')

    # Surprise message
    surprise_message = '''
🎉 Surprise for Jiayin! 🎉

No matter who wins, remember this:
**You are always the best!!!!!!**

I’m always here for you, cheering you on!
With love,
Xi ❤️️
'''
    pen.write(surprise_message, align="center", font=("Arial", 30, "normal"))
    

    return screen
   
def play_the_game():
    '''
    Function: play the game
    play the whole game again and again
    end the game in two situations:
        when the user do not want to roll
        when the user do not want to play again
    print the final results at the end
    '''
    
    # welcome and choose team for player and computer
    screen = setup()
    print_rules()
    
    player_team = (input('What team do you want (boy or girl)? ')).upper()
    computer_team = team_of_computer(player_team)

    # give initial score for both team
    computer_score = 0
    player_score = 0

    while True:
        # get pokemon for both teams and print results
        computer_pokemon = get_player(computer_team)
        player_pokemon = get_player(player_team)
        
        print(f"{computer_team} member {computer_pokemon} vs. "
              f"{player_team} member {player_pokemon}")
        add_image(screen, MIDDLE_X, Y, 'vs.gif')
        add_image(screen, LEFT_X, Y, computer_pokemon + '.gif')
        add_image(screen, RIGHT_X, Y, player_pokemon + '.gif')
        time.sleep(0.5)

        screen.clearscreen()
        

        # check whether keep rolling
        keep_roll = will_roll()

        # if roll, play a round and put the results
        if keep_roll:
            once_result = team_won_once(
                screen,
                computer_pokemon,
                player_pokemon,
                computer_team,
                player_team
            )

            if once_result == 'COMPUTER':
                print(f"My {computer_team} wins with {computer_pokemon}")
                computer_score += 1
            elif once_result == 'PLAYER':
                print(f"Your {player_team} wins with {player_pokemon}")
                player_score += 1
            else:
                print("It's a draw! No winner")

        # if not roll, show the final results of the entire tournament
        if not keep_roll:
            final_result(
                screen,
                computer_team,
                computer_score,
                player_team,
                player_score
            )
            return

        # show end of one round by 3 empty lines
        print('\n' * 3)

        # check whether keep playing
        keep_play = play_or_not()

        if not keep_play:
            final_result(
                screen,
                computer_team,
                computer_score,
                player_team,
                player_score
            )
            return


def main():
    play_the_game()
    
    display_surprise()


if __name__ == '__main__':
    main()
